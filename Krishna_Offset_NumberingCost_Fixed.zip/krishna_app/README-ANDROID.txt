Krishna Printing Press Costing Calculator - Android source project

This is a new Android Studio project. Open this folder in Android Studio and let Gradle sync.
Requirements: Android Studio with Android Gradle Plugin 8.7.3 support, JDK 17, Android SDK 35.

Features:
- Bill book size/type/pages/quantity inputs
- Per-copy paper selection and printing ON/OFF
- Front-only or front+back printing
- Editable paper rates, 18x23 layout pages-per-sheet, printing rates, master/plate rates, binding rates, numbering rate and extra sheets
- Optional numbering and optional binding
- Master OR Plate (only one at a time)
- Total job cost and per-book cost
- Settings stored on device using browser localStorage

Important calculation assumptions in this first build:
- Each copy's sheet count is ceil((pages per book x quantity) / pages-per-sheet) + configured extra sheets.
- Printing impressions are pages-per-book x quantity for each copy with printing enabled; front and back are billed separately.
- Numbering impressions use the total page impressions for copies with printing enabled x counters per page. If your shop's numbering method differs, this can be adjusted.
- Paper rates and binding rates start at ₹0 and should be entered in Settings before using the cost result.

This source package does not include a Gradle wrapper. Use Android Studio to sync/build APK.

Branding update: Krishna Offset launcher icon, in-app logo header, and splash screen are included. Build and install a new APK to see the changes.
